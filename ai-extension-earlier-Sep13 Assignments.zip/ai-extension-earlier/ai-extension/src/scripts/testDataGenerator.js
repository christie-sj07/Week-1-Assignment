// Simple test data generator
export function randomChoice(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

export function randomName() {
  const first = ['Alex','Sam','Jamie','Taylor','Jordan','Morgan','Casey','Riley','Avery','Chris','Pat'];
  const last = ['Smith','Johnson','Brown','Taylor','Anderson','Garcia','Martinez','Lee','Wilson','Clark'];
  return `${randomChoice(first)} ${randomChoice(last)}`;
}

export function randomPhone() {
  const n = () => Math.floor(Math.random() * 10);
  return `(${n()}${n()}${n()}) ${n()}${n()}${n()}-${n()}${n()}${n()}${n()}`;
}

export function randomAddress() {
  const streets = ['Main St','Oak Ave','Pine Rd','Maple Dr','Cedar Ln','Elm St','Park Ave'];
  const nums = () => Math.floor(Math.random() * 9000) + 1;
  const cities = ['Springfield','Fairview','Riverside','Greenville','Franklin','Madison','Oakland'];
  const states = ['CA','NY','TX','WA','FL','IL','PA'];
  const zip = () => (10000 + Math.floor(Math.random() * 89999)).toString();
  return `${nums()} ${randomChoice(streets)}, ${randomChoice(cities)}, ${randomChoice(states)} ${zip()}`;
}

export function randomAccountNumber(length = 12) {
  let s = '';
  for (let i = 0; i < length; i++) s += Math.floor(Math.random() * 10);
  return s;
}

export function randomDOB(minAge = 18, maxAge = 80) {
  const today = new Date();
  const age = minAge + Math.floor(Math.random() * (maxAge - minAge + 1));
  const year = today.getFullYear() - age;
  const month = 1 + Math.floor(Math.random() * 12);
  const day = 1 + Math.floor(Math.random() * 28);
  return `${year}-${String(month).padStart(2,'0')}-${String(day).padStart(2,'0')}`;
}

export function randomEmail(name) {
  const domain = ['example.com','testmail.com','mailinator.com','example.org'];
  const normalized = name ? name.toLowerCase().replace(/[^a-z0-9]+/g,'.') : `user${Math.floor(Math.random()*10000)}`;
  return `${normalized}@${randomChoice(domain)}`;
}

export function randomGender() {
  return randomChoice(['Male','Female','Non-binary','Other']);
}

export function randomCityState() {
  const cities = [
    { city: 'Springfield', state: 'IL' },
    { city: 'Riverside', state: 'CA' },
    { city: 'Greenville', state: 'SC' },
    { city: 'Franklin', state: 'TN' },
    { city: 'Madison', state: 'WI' }
  ];
  return randomChoice(cities);
}

export function generateRecords(selectedFields = [], count = 10, options = {}) {
  const records = [];
  const accountLen = options.accountNumberLength || 12;
  const minAge = options.dobMinAge || 18;
  const maxAge = options.dobMaxAge || 80;

  for (let i = 0; i < count; i++) {
    const r = {};
    if (selectedFields.includes('Name')) r.Name = randomName();
    if (selectedFields.includes('ContactNumber')) r.ContactNumber = randomPhone();
    if (selectedFields.includes('Address')) r.Address = randomAddress();
    if (selectedFields.includes('AccountNumber')) r.AccountNumber = randomAccountNumber(accountLen);
    if (selectedFields.includes('DOB')) r.DOB = randomDOB(minAge, maxAge);
    if (selectedFields.includes('Email')) r.Email = randomEmail(r.Name || `user${i}`);
    if (selectedFields.includes('Gender')) r.Gender = randomGender();
    if (selectedFields.includes('City')) r.City = (randomCityState()).city;
    if (selectedFields.includes('State')) r.State = (randomCityState()).state;
    // keep custom fields if present (user will add fields to selectedFields as custom names)
    selectedFields.forEach(f => {
      if (!['Name','ContactNumber','Address','AccountNumber','DOB','Email','Gender','City','State'].includes(f)) {
        if (!r[f]) r[f] = `${f}_value_${i+1}`;
      }
    });
    records.push(r);
  }
  return records;
}

export function toCSV(records = []) {
  if (!records || records.length === 0) return '';
  const keys = Object.keys(records[0]);
  const lines = [keys.join(',')];
  records.forEach(r => {
    const row = keys.map(k => {
      const v = r[k] == null ? '' : String(r[k]).replace(/"/g,'""');
      return `"${v}"`;
    }).join(',');
    lines.push(row);
  });
  return lines.join('\n');
}

export function downloadCSV(records = [], filename = 'test-data.csv') {
  const csv = toCSV(records);
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

export default { generateRecords, toCSV, downloadCSV };
